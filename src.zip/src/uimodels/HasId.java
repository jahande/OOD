package uimodels;

public interface HasId {
	int getId();
	void setId(int id);
}
