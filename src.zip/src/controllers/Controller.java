package controllers;

public interface Controller {
	void next(Object o, String moduleName, String command);
	
}
