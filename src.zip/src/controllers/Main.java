package controllers;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Controller c = new SimpleController();
		c.next(null, null, "start");

	}

}
