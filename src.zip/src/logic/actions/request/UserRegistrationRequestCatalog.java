package logic.actions.request;


public class UserRegistrationRequestCatalog extends RequestCatalog {

}
