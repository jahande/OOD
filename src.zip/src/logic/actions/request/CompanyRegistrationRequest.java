package logic.actions.request;

import java.util.Date;


public class CompanyRegistrationRequest extends Request {

	public CompanyRegistrationRequest(Date requestDate) {
		super(requestDate);
		// TODO Auto-generated constructor stub
	}

}
