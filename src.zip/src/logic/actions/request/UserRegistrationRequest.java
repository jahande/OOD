package logic.actions.request;

import java.util.Date;


public class UserRegistrationRequest extends Request {

	public UserRegistrationRequest(Date requestDate) {
		super(requestDate);
		// TODO Auto-generated constructor stub
	}

}
