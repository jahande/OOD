package logic.actions;

public class Change {

}
