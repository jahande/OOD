package logic.actions;

public class Assignment {

}
