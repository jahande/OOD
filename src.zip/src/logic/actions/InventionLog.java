package logic.actions;

public class InventionLog {

}
