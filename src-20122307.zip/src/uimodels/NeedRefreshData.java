package uimodels;

public interface NeedRefreshData {
	public void refreshData(Object obj);
}
