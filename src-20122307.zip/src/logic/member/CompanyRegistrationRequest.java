package logic.member;

import java.util.Date;

import logic.Request;

public class CompanyRegistrationRequest extends Request {

	public CompanyRegistrationRequest() {

	}

	public CompanyRegistrationRequest(Date requestDate) {
		super(requestDate);
		// TODO Auto-generated constructor stub
	}

}
