package logic.member;

import logic.Catalog;

public abstract class MemberCatalog implements Catalog {

}
