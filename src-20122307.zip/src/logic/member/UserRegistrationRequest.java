package logic.member;

import java.util.Date;

import logic.Request;

public class UserRegistrationRequest extends Request {
	public UserRegistrationRequest() {

	}

	public UserRegistrationRequest(Date requestDate) {
		super(requestDate);
		// TODO Auto-generated constructor stub
	}

}
